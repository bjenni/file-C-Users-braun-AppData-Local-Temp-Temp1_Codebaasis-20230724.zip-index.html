// Import stylesheets
import './style.css';



// Write Javascript code!

const appDivHeader = document.getElementById('header');
//appDivHeader.innerHTML = `<h1> Header </h1><img src="https://www.haw-landshut.de/fileadmin/Resources/Public/Images/landshut_logo.jpg"/><h4>TODO grüner Hintergrund</h4>`

const appDivMain = document.getElementById('main');
//appDivMain.innerHTML = `<p>Prüfungseinsichten Übersicht</p>`;

const appDivFooter = document.getElementById('footer');
//appDivFooter.innerHTML = `<h3>Footer</h3>`;